import SwiftUI

struct Home: View {
    var body: some View {
        Text("Hello, Home!")
            .padding()
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
