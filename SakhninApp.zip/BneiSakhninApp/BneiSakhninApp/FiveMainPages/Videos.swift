import SwiftUI

struct Videos: View {
    var body: some View {
        Text("Hello, Videos!")
            .padding()
    }
}

struct Videos_Previews: PreviewProvider {
    static var previews: some View {
        Videos()
    }
}
