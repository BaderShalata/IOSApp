import SwiftUI

struct Fixtures: View {
    var body: some View {
        Text("Hello, Fixtures!")
            .padding()
    }
}

struct Fixtures_Previews: PreviewProvider {
    static var previews: some View {
        Fixtures()
    }
}
