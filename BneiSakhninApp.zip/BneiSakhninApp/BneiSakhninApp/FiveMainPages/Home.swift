import SwiftUI

struct Home: View {
    var body: some View {
        Text("Hello, SwiftUI!")
            .padding()
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
