import SwiftUI
import FirebaseCore

@main
struct BneiSakhninApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            SignInView()
        }
    }
}
