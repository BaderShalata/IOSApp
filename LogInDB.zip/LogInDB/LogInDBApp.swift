import SwiftUI
import FirebaseCore

@main
struct LogInDBApp: App {
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
