import SwiftUI

struct More: View {
    var body: some View {
        Text("Hello, SwiftUI!")
            .padding()
    }
}

struct More_Previews: PreviewProvider {
    static var previews: some View {
        More()
    }
}
