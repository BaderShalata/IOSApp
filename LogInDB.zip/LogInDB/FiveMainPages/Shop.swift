import SwiftUI

struct Shop: View {
    var body: some View {
        Text("Hello, SwiftUI!")
            .padding()
    }
}

struct Shop_Previews: PreviewProvider {
    static var previews: some View {
        Shop()
    }
}
